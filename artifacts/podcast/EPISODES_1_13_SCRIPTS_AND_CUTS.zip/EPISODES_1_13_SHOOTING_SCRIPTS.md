# THE OTHER PERSON IN THE ROOM
## Expanded shooting scripts — Episodes 1–13
**Host:** Adam James  
**Target runtime:** 10–15 minutes each (perform at conversational pace, leave the silences)  
**Prologue:** unchanged. Do not expand.  
**Style:** live table talk. Interrupt. Argue. Comedy first, then the cost. Illness is a roommate, not a monster.

Spoken content notes at the top of every episode. No methods. No spectacle.

Pacing note for recording: ~140 words per minute with interruptions. Each script below is built for 10–12 minutes once you leave the gaps. Do not tidy the overlap out.

---

## EP 1 — SARAH + ANXIETY
**Title:** The Clipboard  
**Content note:** Anxiety, hypervigilance, the mental load of constant checking.

ADAM: Content note. Anxiety. Checking. The mental load of a brain that will not clock off. I'm Adam James. This is The Other Person in the Room. Episode one. Sarah.

SARAH: You put the chair there again.

ADAM: You asked for it last time.

SARAH: I was being funny.

ADAM: You were being honest. That's worse. Backyard. Cold tea. Dog on your foot. Empty chair behind your left shoulder. Introduce the housemate.

SARAH: Clipboard. Disappointed face. Never taken a day of leave. If HR existed in my skull this would be the person who replies all.

ANXIETY: I can hear you.

SARAH: Good. Sit further back.

ANXIETY: I sit where the exits are. That's the job.

ADAM: When did the job start.

SARAH: Eleven. School camp. Plastic tray. Dining hall. Suddenly I am not worried, I am certain, that if I eat the food I will choke and everyone will be annoyed at me for making a scene. Most kids get homesick. I opened a risk-assessment department overnight.

ANXIETY: The building also looked flammable.

SARAH: It was a gym.

ANXIETY: Have you seen gyms.

SARAH: I was eleven!

ADAM: What did you tell the teacher.

SARAH: Homesick. Homesick has an end date. This didn't. Then I went home and started locking the house like it was a diplomatic compound. Dad thought I was becoming responsible. No one thinks an eleven-year-old doing perimeter sweeps is weird. They think it's cute. It was not cute.

ANXIETY: It was thorough.

SARAH: It was unpaid overtime.

ADAM: What does a normal Tuesday feel like now. And don't say fine.

SARAH: Fine is the costume. Underneath it's maths. Did I lock the door. Did I see myself lock it or only think I locked it. Is that noise the house settling or the start of a disaster. I can answer an email and run a full probability model at the same time. It's a talent. I would like it refunded.

ANXIETY: She keeps the people she loves safe. You're welcome.

SARAH: I keep them waiting in car parks while I go back inside to check a stove that is already off.

ADAM: I used to tease you about that.

SARAH: I know. It wasn't a quirk.

ADAM: I know that now. I'm sorry. Chair. What do you actually want from her.

ANXIETY: Certainty. Laminated. Notarised. Nothing bad happens on her watch. Is that so much to ask.

ADAM: Yes.

SARAH: Yes.

ANXIETY: Rude. Both of you. She keeps trying, which is why I keep her employed.

SARAH: It just called me staff.

ANXIETY: You are staff. Job title: prevent catastrophe. The KPIs are impossible. I still expect overtime.

ADAM: What do you tell her at three in the morning.

ANXIETY: That the previous fifty safe moments are statistically irrelevant. That the next one is the dangerous one. Happiness is when people get sloppy. I cannot have sloppy.

SARAH: You have never once said well done on the fifty safe moments.

ANXIETY: That's the baseline. You don't get a medal for not burning the house down.

SARAH: That's my daily affirmation. Printed. Framed. In the bathroom.

ADAM: Has it ever been right.

SARAH: That's the bastard part. Once every few years it catches something real. A gas smell. An actual problem. Then it walks around like it invented risk assessment. The rest of the time it's screaming at leaves.

ANXIETY: I keep the receipts for the useful times. I delete the rest. Data-driven.

SARAH: You're an arsehole with a filing system.

ANXIETY: Semantics.

ADAM: When did it get a name.

SARAH: Twenty-six. GP. She said generalised anxiety disorder and the room tilted. Relief first. Then this shrinking. Suddenly I was a diagnosis in a file. For a while I introduced myself in my head as Sarah who has anxiety, as if the second half was the more important identity.

ANXIETY: The name made me official. Before, I was background noise. After, she had to negotiate with me in public. I prefer that.

SARAH: My mother said we all get worried sometimes. She meant well. It landed like dismissal.

ADAM: What do you hide.

SARAH: The bathroom-floor minutes. The messages I write and delete. The plans I cancel with a clean lie about work. I am afraid people would leave if they saw the private version. Or worse, stay out of pity. Pity is its own kind of distance.

ANXIETY: Pity keeps her useful. Useful people don't get left.

SARAH: You keep saying useful like it's a compliment.

ANXIETY: It is the highest compliment I have.

ADAM: Do you want it gone.

SARAH: No. And I hate that the answer is no. I want it quieter. I want it in the corner, not in the doorway. I want fewer pages on the clipboard. When I cancel, it's not because I don't care. It's because I lost the argument with this thing and I'm too tired to appeal.

ANXIETY: I'll take it under advisement.

SARAH: You always say that.

ANXIETY: No promises.

ADAM: Specific night. Your birthday. Two years ago. I was there.

SARAH: I had cooked. I had cleaned. I had checked the locks four times before anyone arrived because if the house burned down on my birthday that would be a very on-brand tragedy. Then I spent the whole night watching the oven like it was a suspect. At eleven I said I was tired. I wasn't tired. The clipboard had decided overnight guests were an unacceptable variable.

ANXIETY: Overnight guests are how houses burn down.

SARAH: No one was smoking. The oven was off. The candles were out.

ANXIETY: You think you saw the oven off. Seeing is not the same as checking.

ADAM: I thought you were ready for us to leave.

SARAH: I wanted you to stay. I also wanted you gone. Both things. The clipboard wins the tie.

ADAM: If you could write a new contract.

SARAH: You can warn me. You cannot veto my life. You can keep a small clipboard. You cannot staff me. One check of the stove, not seven. And if I laugh, that is not an emergency. That is me still being in the house.

ANXIETY: I'll take it under advisement.

SARAH: If you say no promises I am putting you in the shed.

ANXIETY: The shed is flammable.

SARAH: Of course it is.

ADAM: What do you want people listening to do tonight.

SARAH: If someone you love cancels, believe the first reason. If they check the door twice, let them. If they go quiet, stay in the room without turning it into a project. If they joke about the clipboard, laugh. Then take it seriously. Both. That's the whole trick.

ADAM: Clipboard still in the chair. Sarah still in the house. That's the episode. Next time: Marcus, and the landlord.

---

## EP 2 — MARCUS + DEPRESSION
**Title:** The Landlord  
**Content note:** Depression, numbness, isolation, persistent low mood.

ADAM: Content note. Depression. The long quiet. I'm Adam James. Episode two. Marcus.

MARCUS: You opened the blinds.

ADAM: You opened them. Two coffees actually being drunk. Empty chair that already looks exhausted. Introduce your housemate.

MARCUS: Tired. Older than me. Sits like it's paying rent and I'm the difficult tenant. Landlord energy. Given up on renovations. Just wants everyone to stop asking for things.

DEPRESSION: The renovations were never going to help.

MARCUS: See. That's the voice. Polite demolition.

ADAM: When did it move in.

MARCUS: Sixteen. Kitchen. Father left. Door closed and the house went quiet in a way that felt structural. I waited for sadness or rage. Instead there was thick, heavy nothing. I thought it was shock. Shock is meant to pass. This one signed a lease.

DEPRESSION: I was already in the kitchen. He just noticed me.

MARCUS: I told everyone I was tired for twenty years. Tired is the Swiss Army knife of cover stories. Very effective. Also completely full of it.

ADAM: How would the people closest to you describe you.

MARCUS: Reliable. Until I'm not. Funny, until the humour drains out. The one who turns up with tools when your tap is leaking. Then the one who disappears for six weeks. They describe both versions like they're the same person. I'm not sure they are.

DEPRESSION: They are. He's just quieter in one of them.

ADAM: What does it say when it's strong.

MARCUS: It doesn't shout. That's the scam. It waits until you agree. Effort is pointless. You're already behind. People would be better off if you stayed still. It's like being talked out of your own life by someone with excellent manners.

DEPRESSION: Manners are efficient. Shouting is for amateurs.

ADAM: Chair. What do you want from him.

DEPRESSION: Rest. Permanent rest. Stop performing competence. Stop hoping tomorrow will be different. The hope is frankly embarrassing for both of us.

MARCUS: It's very polite about the demolition. That's the worst part.

DEPRESSION: I'm doing him a favour. Without me he'd have to believe the emptiness is personal. This way it has an explanation. You're welcome.

MARCUS: I hate that I sometimes find that comforting.

ADAM: I used to invent reasons when you left after forty minutes.

MARCUS: I know. Work. Tired. Busy. You were being kind. You were also being wrong.

ADAM: Yeah. I was. What do you hide.

MARCUS: The scale of the nothing. The weeks when getting to the shower feels like crossing a country. Sitting in a room full of people I love and feeling unreachable. I hide the duration more than the intensity. Intensity can be excused. Duration starts to look like character.

DEPRESSION: Hiding is mutual. He hides me so people will not leave. I hide the full weight so he will not panic. Almost romantic if you ignore how unhelpful it is.

MARCUS: Don't call it romantic.

DEPRESSION: Fine. Administrative.

ADAM: Last winter. Nine days. Tell me.

MARCUS: I answered two messages with thumbs-up because a sentence felt like a mountain. I showered on day four and felt like I'd run a marathon. You texted, you coming Sunday. I said maybe. Maybe is the most dishonest word I own. Maybe meant no, and I didn't have the energy to be a person who says no out loud.

DEPRESSION: Maybe is a kindness. It keeps their hope alive without requiring your body.

MARCUS: Maybe is how people stop inviting you. Then you get to say see, they left, which is your favourite evidence.

DEPRESSION: I don't make them leave. I make staying expensive. There's a difference.

ADAM: What should I have done that week.

MARCUS: Come over with food and no speech. Sit on the couch. Don't ask how I'm feeling every ten minutes. Don't look disappointed when the answer is nothing. Nothing is an answer. Stay anyway. Leave leftovers. Text tomorrow like I didn't fail you.

DEPRESSION: Company is a demand wearing a nice jumper.

MARCUS: Company is how I remember I still have a body in a room. You prefer me bodiless. I don't.

ADAM: If you could write a new lease.

MARCUS: You can visit. You cannot redecorate. You don't get to call rest the only honest response. You don't get to make hope embarrassing. And you don't get to talk me out of Sunday just because Sunday requires shoes.

DEPRESSION: Shoes are a performance of competence.

MARCUS: Shoes are how I get to the shop. I'm keeping the shoes. You can keep the armchair. That's the deal.

ADAM: That's the episode. Landlord still collecting. Marcus still here. Stay anyway. Next time: Elena.

---

## EP 3 — ELENA + TRAUMA
**Title:** The Security Guard Who Never Clocks Off  
**Content note:** Trauma, hypervigilance, body memory. No graphic events.

ADAM: Content note. Trauma. Hypervigilance. Body memory. No graphic events. I'm Adam James. Episode three. Elena.

ELENA: You left the hallway light on.

ADAM: You left it on. I followed the house rules. Empty chair by the door. Who's in it.

ELENA: A very tired security guard who never clocks off. Always scanning. Convinced that if it relaxes for one second the original threat will walk back in wearing a different coat. Loyal in the most exhausting way possible.

TRAUMA: Loyal is the correct word.

ELENA: Exhausting is also the correct word.

ADAM: Who were you before this had a name.

ELENA: Louder. More trusting. I danced in kitchens. I assumed tomorrow would be roughly the same shape as today. I thought danger announced itself clearly, like a weather warning. I didn't know the body could keep a private archive without telling the owner.

ADAM: When did you notice it.

ELENA: Not one clean moment. Small mutinies. Smoke that wasn't there. Waking up already braced. A certain tone of voice emptying a room. People thought I was distracted. I was in a different year.

TRAUMA: The year is still available. That's why I'm here.

ELENA: The year is over. That's why I'm arguing with you.

ADAM: Chair. What do you want from her.

TRAUMA: Vigilance. Continuous. Unbroken. The past is not finished with us. If she forgets, it returns without warning. I have seen this movie. I did not like the ending.

ELENA: It thinks it's the only adult in the room.

TRAUMA: I am the only adult in the room. The rest of you are acting like the war is over.

ADAM: Has it ever been right.

ELENA: Yes. That's the trap. Every now and then it catches something genuine. Those moments become the evidence for the other ninety-nine times it was wrong. Excellent at selective memory.

TRAUMA: Selective memory is good record-keeping. I keep us alive. She can call it a prison. I call it a security contract with no exit clause.

ELENA: And that is how a prison gets built out of old alarm systems.

ADAM: Tell me about a room you walked out of that looked completely normal.

ELENA: A barbecue. Someone slammed a screen door. That's it. That's the whole plot. My body left the year. I was smiling and I was also twelve years ago. I went to the bathroom and sat on the closed lid until the year came back. Then I made a joke about the food and drove home. People thought I was tired. I had time-travelled without consent and then driven a car. That's the part that still makes me angry. Not the slam. The fact that I had to make it look like nothing.

TRAUMA: The slam was not nothing. That's how it starts.

ELENA: A screen door is a screen door. You don't get to staff every hinge in the city.

TRAUMA: I staff the ones that sound like the original. That's the contract.

ADAM: What do you want from me when that happens.

ELENA: Don't follow me into the bathroom. Don't ask what I remembered. Don't make a story out of my face. Text later. I'm still here. That's the whole message I need. And don't stand behind me at the sink. Ever. That's not a quirky preference. That's architecture.

TRAUMA: He shouldn't be in the kitchen at all.

ELENA: He's my friend. He's allowed in the kitchen. You are the guest who won't take off your boots.

ADAM: If you could rewrite the security contract.

ELENA: You can keep the night shift. You cannot keep the whole calendar. You get to warn. You do not get to veto barbecues, hallways, or sleep. I'm still here. That is not suspicious. That is the point.

TRAUMA: I'll take it under review.

ELENA: You don't get review. You get a chair by the door and one hour off. We're starting with the hour.

ADAM: I used to think the way you sat in rooms was personality.

ELENA: It was architecture. I built exits into every conversation. Some rooms I still don't open. Including for myself. Don't push those.

ADAM: I won't. Guard still at the door. Elena still here. That should count. Next time: David, and the weather.

---

## EP 4 — DAVID + BIPOLAR
**Title:** The Weather  
**Content note:** Bipolar mood states. Highs. Crashes.

ADAM: Content note. Bipolar mood states. I'm Adam James. Episode four. David.

DAVID: The chair's already arguing with itself. That's accurate.

ADAM: How many people are fighting in that chair.

DAVID: Two. One wants confetti and a three-day plan to reinvent the self. The other wants the curtains closed and the phone in another postcode. They share a body like a bitter divorced couple forced to co-parent a nervous system.

BIPOLAR: We don't take turns politely.

DAVID: You don't take turns at all.

ADAM: What does the high feel like.

DAVID: Like being the most interesting person at a party only I was invited to. Ideas faster than I can write them down. Charm turned up until I forget there are other people in the room.

BIPOLAR: That's called being fully switched on.

ADAM: And the crash.

DAVID: Waking up in a different country with no passport and a hangover made of concrete. Both versions are real. Not performances. Weather systems moving through the same body.

ADAM: Chair. What do you want from him.

BIPOLAR: Range. Full range. The quiet version of him is safer and also deeply boring. I bring the weather. Sometimes it's a festival. Sometimes it's a blackout. I don't do mild.

DAVID: Mood stabilisers narrowed the range. I missed the high. I did not miss the crash. Most days the trade is worth it. Some days I still miss the festival even though I know how it ends.

BIPOLAR: I notice the blackout. I simply refuse to apologise for the voltage. You don't apologise for electricity.

DAVID: People do, actually, when the electricity knocks the power out for the whole street.

BIPOLAR: The dimmer switch version is for other people.

DAVID: The dimmer switch version is how I keep a job and a friendship and a plant alive.

ADAM: Give me a festival and a blackout the same friends had to live through.

DAVID: The festival: I planned a three-day trip in forty minutes, invited eight people, booked nothing properly, and convinced everyone it would be the best weekend of their lives. Some of it was. I was electric. I also didn't sleep. I also spent money I didn't have. The blackout arrived on the Tuesday. I cancelled on everyone with a one-line message and didn't leave the house for six days. Same friends. Same body. Two different tenants answering the door.

BIPOLAR: The weekend was alive. The Tuesday was a correction. You don't get one without the other.

DAVID: That's the sales pitch. I'm not buying it anymore. I like being alive. I also like being someone people can make plans with. Those shouldn't be opposites.

ADAM: What should friends do with the forecast.

DAVID: Don't cancel me when I'm bright. Don't abandon me when I'm dark. Don't say this is the real you about either version. If I am making plans at speed, help me put one foot on the brake without humiliating me. If I have gone dark, bring the boring kind of company. Not a rescue. A sandwich. A sit. The weather passes. The people don't have to.

BIPOLAR: He wants a climate. I am weather. We are going to keep arguing.

DAVID: Yes. That's the marriage. I'm not filing for eviction. I'm filing for a thermostat and a shared calendar.

ADAM: Both versions of you are real. Don't only love the sunny days. Next time: Priya, and the endless play.

---

## EP 5 — PRIYA + OCD
**Title:** The Endless Play  
**Content note:** OCD patterns, sequences, cost of rituals.

ADAM: Content note. Obsessive-compulsive patterns. I'm Adam James. Episode five. Priya.

PRIYA: Don't touch the chair. I just fixed it.

ADAM: I wasn't going to. Introduce the third person.

PRIYA: Precise. Exhausted. Holding a script that grows new pages while you're watching. Never shouts. Just repeats the stage direction until the actor complies out of sheer defeat.

OCD: The chair is still not correct.

PRIYA: I know. That's why we're here.

ADAM: What do the sequences feel like from the inside.

PRIYA: Compulsory dress rehearsals of catastrophe. If I don't complete the sequence, the catastrophe becomes more likely. The sequence is never finished, only paused. It is not a choice I enjoy. It is the tax I pay for a quieter mind. Some days the tax is too high. I pay it anyway.

OCD: If she skips a scene the danger stays active. I am not being difficult. I am being complete.

ADAM: Chair. What do you want.

OCD: Completeness. I am the only one treating the threat with the seriousness it deserves.

PRIYA: The relief after finishing lasts approximately forty seconds. Then the next cue arrives like an unpaid intern who doesn't understand weekends.

OCD: Forty seconds of safety is still safety. You're welcome. The play does not close because the risk does not close. That is called consistency.

PRIYA: That is called a full-time job I never applied for and cannot resign from. Don't tell me to just stop. If I could just stop, I would have stopped years ago.

ADAM: I will not tell you to just stop.

PRIYA: Good. That's the first useful sentence of the hour.

ADAM: Tell me about a time the play made you late for something you actually wanted.

PRIYA: My sister's dinner. I was dressed. I was in the hallway. Then the sequence started at the door. Lights. Taps. The bag. The door again. Forty seconds of relief, then another cue. I arrived an hour late with a story about traffic. There was no traffic. There was a play that would not close. She was kind. Kindness with a question mark in it. I wanted to say I would have crawled there if the script had allowed it. Instead I said sorry about the traffic. I still hate that lie.

OCD: The door was not finished. Unfinished doors are how things get in.

PRIYA: My sister was the thing trying to get in. You made me late for love and called it security.

ADAM: What do you want people to do when you're late.

PRIYA: Hold the seat. Don't narrate the lateness. Don't say we started without you like a punishment. When I arrive, let me arrive. I have already paid the tax. I do not need to pay it again in the doorway.

OCD: If they start without her the danger increases. That's why we don't leave.

PRIYA: We leave. That's the new scene. You can come. You cannot block the door.

ADAM: Do you want it gone.

PRIYA: I want the play quieter. Gone feels like leaving the theatre unlocked. Quieter I can live with.

OCD: Quieter is sloppy.

PRIYA: Quieter is how I keep a life. Script still on the table. I'm still here. Next time: Tom.

---

## EP 6 — TOM + ADDICTION
**Title:** The Ex Who Still Has a Key  
**Content note:** Addiction and recovery. No using detail.

ADAM: Content note. Addiction and recovery. No using detail. I'm Adam James. Episode six. Tom.

TOM: Park bench. I picked it because there's no fridge.

ADAM: Fair. Is the third person here.

TOM: An ex who still has a key and occasionally tries the door. Charismatic. Remembers every good night and none of the damage. I don't let it move back in. I know the sound of its footsteps in the hallway.

ADDICTION: I have excellent timing.

TOM: That's not a compliment.

ADDICTION: I didn't ask for one.

ADAM: How did the bargain start.

TOM: Fun at the beginning. Made everything easier, louder, more possible. Then it started rewriting the lease. The next one will be different. This time the terms will be mine. They never were.

ADAM: To the space. What did you offer him.

ADDICTION: Relief. Immediate. Reliable. Temporary. I solved the feeling when nothing else was working. The terms were always mine. He just stopped reading the fine print.

TOM: Recovery is not a single dramatic turning point. It is a thousand small, deeply unsexy decisions. Celebrate the boring parts. They are the ones that keep the door locked.

ADDICTION: He can call it a problem now that he's sober and boring. I call it the only solution that ever showed up on time. I can wait. I am extremely patient.

TOM: I know. That's why the ordinary Tuesdays matter more than the crisis nights.

ADAM: Give me a Tuesday that actually counted.

TOM: A nothing Tuesday. Rain. I wanted the old solution the way you want a person you shouldn't call. I made tea. I walked to the shop and back. I sent a message to one person that said still here, boring on purpose. They replied good. That's the whole heroic arc. No speech. No anniversary. Just a door that stayed locked because I did five small unsexy things in a row.

ADDICTION: I was in the hallway the whole time. He just didn't open.

TOM: Correct. That's the job now. Not never hearing you. Not opening.

ADAM: What do you want from the people who love you on those Tuesdays.

TOM: Don't wait for a collapse to become interested. Don't make the quiet week a test I can fail. Come over. Watch something dumb. Leave. No inspection of my soul at the door. Celebrate the boring parts out loud once in a while so I remember they're the point.

ADDICTION: Boredom is a gap. I am very patient with gaps.

TOM: Then I'll fill them with Tuesdays until your patience looks silly. Key still in the other pocket. I still live here. Next time: Aisha.

---

## EP 7 — AISHA + PANIC
**Title:** National Emergency  
**Content note:** Panic attacks. Sudden bodily emergency. False alarms that still feel real.

ADAM: Content note. Panic attacks. False alarms that still feel like the real thing. I'm Adam James. Episode seven. Aisha.

AISHA: Door's visible. I already checked. Don't close it.

ADAM: I won't. Who's in the room.

AISHA: Loud. Certain. Completely uninterested in proportion. Treats a slightly elevated heart rate like the building is on fire and the exits are blocked by bees.

PANIC: Evacuation. Now.

AISHA: We just sat down.

PANIC: Irrelevant.

ADAM: What does it feel like when it arrives.

AISHA: National emergency declared by a body that did not consult me. A supermarket aisle can become a disaster movie in under ten seconds. The false alarms still require full evacuation. Very committed to the bit. The body is a terrible narrator and an excellent alarm system at the same time.

ADAM: Chair. What do you want.

PANIC: Evacuation. I do not do maybe later. I do not do let's assess. This time is different. It is always this time. The previous fifty times being wrong is irrelevant data.

AISHA: Don't tell me to calm down. That is the least helpful sentence in the English language. Help me get somewhere safe until the false alarm finishes its shift. Presence without matching panic is the only useful offering.

PANIC: I will finish when I finish. Your schedule is not my problem.

ADAM: I've said calm down before. I'm sorry.

AISHA: You meant well. Meaning well still sounds like an argument with a fire alarm.

ADAM: The supermarket.

AISHA: Cereal aisle. Heart goes from commuting to sirens in under ten seconds. Lights too bright. Trolley suddenly a trap. I left the trolley. I sat in the car with the door open until the false alarm finished its shift. A man asked if I was okay. I said I'm fine, which is the house special. I wasn't in medical danger. I also wasn't shopping. Both can be true.

PANIC: This time was different.

AISHA: It was cereal.

PANIC: Cereal aisles have no exits that count.

ADAM: If I'm with you in that aisle, what do I do.

AISHA: Don't say calm down. Don't make a scene that matches the scene in my chest. Offer the car. Offer the smaller room. Sit next to me without narrating my pulse. When it's over, don't demand a TED talk. Buy the cereal later. That's it. That's the care.

PANIC: He cannot schedule me.

AISHA: You will finish. You always do. I just refuse to let you drive. Alarm quiet. I'm still in the room. Next time: Liam.

---

## EP 8 — LIAM + REJECTION SENSITIVITY
**Title:** Advanced Pattern Recognition  
**Content note:** Rejection sensitivity. Ordinary feedback landing like an ending.

ADAM: Content note. Rejection sensitivity. I'm Adam James. Episode eight. Liam.

LIAM: The chair already thinks you're about to dump me. That's not a joke.

ADAM: I'm not dumping you. Introduce the third person.

LIAM: Hyper-alert. Treats ordinary feedback like the opening scene of a tragedy. Means well in the most relationship-destroying way possible.

REJECTION: I am simply reading the subtext.

LIAM: There is no subtext. He asked how I was.

REJECTION: That's how it starts.

ADAM: What does it actually feel like.

LIAM: I need a bit of space arrives in my nervous system as I am leaving forever and also you were never enough. I have pre-emptively ruined things that were not actually ending. Impressive talent. I would like to return it.

ADAM: Chair. What are you trying to do.

REJECTION: Protect him. If I react first, the abandonment cannot blindside us. Better to end it myself than wait for the inevitable. I look closely enough for both of us.

LIAM: Translate feedback like you're speaking to someone whose nervous system is convinced every sentence contains a hidden exit. I am listening. It just doesn't look like it from the outside.

REJECTION: He can call it sensitivity. I call it advanced pattern recognition with a strong bias toward survival.

ADAM: Tell me about a thing you ruined that was not actually ending.

LIAM: They said I need a bit of space this week. I heard I am leaving forever. I wrote a message that was half apology half pre-emptive strike. I sent it. They were confused. Then they were tired for real. I had built the exit I was afraid of.

REJECTION: You got ahead of the pain. That's the win.

LIAM: I created the pain. That's the loss. Stop calling it a win.

ADAM: How do I give you feedback without triggering the scanner.

LIAM: Start with I'm not going anywhere. Then the thing. Then I'm not going anywhere again. Stay in the room after. Don't drop the honesty and leave. I can hear hard things. I cannot hear hard things plus a slammed door.

REJECTION: I'm not going anywhere is how they get you.

LIAM: It's also how I stay. I'm picking stay. You can keep the scanner. You don't get the send button. Next time: Sophie.

---

## EP 9 — SOPHIE + DYSMORPHIA
**Title:** The Hostile Witness  
**Content note:** Body image. History of disordered eating. No behaviours. No numbers.

ADAM: Content note. Body image. No behaviours. No numbers. I'm Adam James. Episode nine. Sophie.

SOPHIE: Don't look at the mirror. It will take it personally.

ADAM: I'm looking at you. The critic is present. What does it look like.

SOPHIE: Precise. Exhausting. Holds a set of measurements that reality keeps failing to meet. Has never once said good enough. The mirror has never been a neutral party. It has always been a hostile witness with excellent lighting for cross-examination.

DYSMORPHIA: I am the only one seeing clearly.

SOPHIE: You are the only one with a vendetta.

ADAM: What did treatment mean.

SOPHIE: Learning that the mirror is not an objective witness. That sentence took about a decade to stick and still needs daily reminders. The people who love me have learned not to comment on my body. That silence is its own kind of care.

ADAM: Chair. What do you want from her.

DYSMORPHIA: Accuracy. Everyone else is being kind or delusional or both. The measurements do not lie. Kindness does.

SOPHIE: Don't try to compliment me out of it. Just don't become another voice agreeing with the hostile witness. The most useful thing anyone has offered me is refusing to join the opposing counsel.

DYSMORPHIA: She can call it a disorder. I call it the last honest voice in the room.

SOPHIE: You are not honest. You are certain. Those are not the same.

ADAM: Tell me about a compliment that made it worse.

SOPHIE: Someone at a dinner said I looked well. They meant kind. The witness heard a measurement. The rest of the night I was in the dock. Kindness aimed at the battlefield still looks like a weapon to the part of me that only speaks in evidence. Talk about the food. Talk about the joke. Leave my body out of the minutes.

DYSMORPHIA: They noticed. Noticing is data.

SOPHIE: Noticing is not a verdict. You don't get to enter every sentence as Exhibit A.

ADAM: What does care look like from me, specifically.

SOPHIE: Don't comment. Don't stare. Don't ask if I've eaten like a probation officer. Ask about work. Ask about the dog. If I leave a room, let me leave. If I come back, let me come back. The mirror is a hostile witness. You don't have to be opposing counsel. That's the whole job.

DYSMORPHIA: I will still be here when she looks.

SOPHIE: And I will still look away on purpose. That's my evidence. File it. Next time: Jordan.

---

## EP 10 — JORDAN + GRIEF
**Title:** The Space That Won't Vacate  
**Content note:** Grief. Death of a sibling. The long shape of absence.

ADAM: Content note. Grief. The death of a sibling. I'm Adam James. Episode ten. Jordan.

JORDAN: You can sit. Just not in that space.

ADAM: I won't. Is the third person here.

JORDAN: Yes. Quiet. Heavy. Permanent. Doesn't shout. Just sits in the exact space my brother used to occupy and refuses to vacate. I wouldn't ask it to leave. That would be another death.

GRIEF: I do not leave. That is the entire job description.

JORDAN: See. That's not a threat. That's a fact.

ADAM: What did the day after the funeral feel like.

JORDAN: Time simply declined to resume its previous shape. Everyone else kept the old calendar and looked at me like I was being difficult for not updating. Grief does not do deadlines. Anyone waiting for me to be over it is waiting for a train that was never scheduled. I don't want it erased. It is the shape love takes when the person is gone.

ADAM: To the space. What do you want.

GRIEF: Continuity. I am the proof the love was real. Without me the absence becomes clean and therefore false. I stay so the love still has somewhere to go. You're welcome.

JORDAN: Sit with me instead of trying to move me along. The missing person can be present without destroying the present. That is the only version of healing that hasn't felt like betrayal.

ADAM: Tell me about a sentence that made it louder.

JORDAN: He'd want you to be happy. People say it like a blessing. It lands like an eviction notice. As if the love has a finish line and I am being difficult for not crossing it. My brother is not a motivational poster. He is a person who is gone. I can laugh and still need the space. Both.

GRIEF: They want the absence clean. Clean is false.

JORDAN: Don't clean it. Sit in it with me. Talk about him like he existed. Use his name. Don't look at your watch when I do.

ADAM: What do you want from the calendar.

JORDAN: Permission not to reset it. No deadline. No over it. Sit with me. That's the only healing that hasn't felt like betrayal.

GRIEF: I do not leave. That is the job.

JORDAN: Then we do the job. Quietly. For as long as it takes. Next time: Mei.

---

## EP 11 — MEI + SOCIAL ANXIETY
**Title:** The Thermostat  
**Content note:** Social anxiety. Fear of judgement. The cost of ordinary rooms.

ADAM: Content note. Social anxiety. I'm Adam James. Episode eleven. Mei.

MEI: Corner table. I picked it. Don't make me move.

ADAM: I won't. Introduce the third person.

MEI: Alert. Exhausted. Holding a clipboard of every possible wrong sentence and the precise social death that would follow. Trying to keep me safe from humiliation. Succeeding at keeping me very small.

SOCIAL: Small is safe.

MEI: Small is also how you miss your own life.

ADAM: What happens when you enter a room with more than three people.

MEI: Continuous risk assessment. Silence is not coldness. Sometimes it is the only way I can stay in the room without combusting. Progress is very unglamorous.

ADAM: Chair. What's the goal.

SOCIAL: Safety through silence and accuracy. Every sentence is a potential exit wound. Better to say nothing than to say the thing that makes them leave. I am the thermostat. I keep the temperature low enough that no one gets burned. Including her.

MEI: Thank you for staying in the room even when I'm quiet. The quiet is the sound of me choosing to stay. It's expensive.

ADAM: What does staying in the room cost you.

MEI: Heat. Calculation. The feeling of holding a sentence in my mouth until it goes cold. People think quiet is easy. Quiet is work. If you stay beside the quiet without filling it, that is the kindest thing you can do.

SOCIAL: Filling the quiet is how mistakes get in.

MEI: And I will keep sitting here anyway. That is the whole sentence.

ADAM: I used to think you were distant.

MEI: I was present. Presence just didn't look like talking. Map the room if you need to. Then sit down. My silence is often the sound of me staying. Next time: Alex.

---

## EP 12 — ALEX + THE LOW VOICE
**Title:** The Question That Stays Open  
**Content note:** Persistent low mood. A quiet voice that drains the colour out of effort.

ADAM: Content note. Persistent low mood. A quiet voice that questions effort. I'm Adam James. Episode twelve. Alex.

ALEX: You don't have to whisper. It already heard you.

ADAM: Who's in the chair.

ALEX: Persistent. Not theatrical. Doesn't need to raise its voice. Just keeps a low-grade radio on in the background. Questions the point of effort. Not with a plan. Just with the steady suggestion that trying is overrated and rest is the only honest move.

LOW VOICE: I am the question that keeps him honest.

ALEX: You are the question that keeps him tired.

ADAM: Chair. What do you actually want.

LOW VOICE: Perspective. Without me he might start believing the effort is easier than it is. I don't demand anything dramatic. I only refuse to let the question close. Why bother. That's the whole song. On a loop.

ALEX: I bother anyway. That is also true. Both realities live in the same body. The most useful sentence anyone ever gave me was: you don't have to feel better to keep going. You just have to keep going. Still paying rent on that sentence.

LOW VOICE: He answers the question every day by remaining in the work. The answer is his. The question remains mine. I'm consistent like that.

ALEX: Don't try to argue it into silence in one conversation. Just be one of the reasons going feels slightly more possible than not going. Presence without pressure. That's the only intervention that has ever worked. The low voice is not the whole truth. I keep showing up. That is also the truth.

ADAM: What does support look like on a low day.

ALEX: Someone in the room who does not need me to perform better. A message that does not require a paragraph back. Food that does not come with a speech. I am not asking anyone to argue the voice out of existence. I am asking them to be one of the reasons the answer stays yes.

LOW VOICE: The question will still be here in the morning.

ALEX: So will I. So will the kettle. So will the boring work of remaining in my own life. You can keep the question. I keep the kettle.

ADAM: I used to try to cheer you up.

ALEX: I know. It made the voice louder. Cheer is a demand. Presence is an offer. Offer is better. The radio is still on. I am still here. If this one sat heavy, support lines are in the show notes. Lifeline in Australia is thirteen eleven fourteen. Finale next.

---

## EP 13 — FINALE
**Title:** The Other Person Was Me

ADAM: Content note. This finale gathers the whole series. Same subjects. Same care. I'm Adam James. Last episode of The Other Person in the Room.

The interviews changed the way I understand my friends. They also forced me to look at the rooms I have been living in without introducing the occupants. Fear. Grief. Shame. The parts of myself I never quite knew how to name.

I used to think the point was to understand the people I love more clearly. That happened. What also happened is I had to admit the ways I have been a difficult tenant in my own life. The cancelled plans I never explained. The performances of fine. The rooms I locked from the inside.

I asked each of the twelve one last question. If you could introduce the person you are now to the person you were before all of this began, what would you say. Their answers were different. The shape of the answers was the same. You made it. The other person did not get the whole house. You are still here.

SARAH: I want the clipboard quieter. Not gone.
MARCUS: Stay anyway.
ELENA: I'm still here. That is the part that matters.
DAVID: Loving me means making room for the weather.
PRIYA: Reliability looks different on me.
TOM: Celebrate the boring parts.
AISHA: Presence without matching panic.
LIAM: Translate gently. I am listening.
SOPHIE: Silence about my body is care.
JORDAN: Sit with me. There is no deadline.
MEI: The quiet is the sound of me staying.
ALEX: You don't have to feel better to keep going. You just have to keep going.

ADAM: I used to think friendship automatically gave you a key to every room. It doesn't. Love does not grant access to the other person in the room. Sometimes the most loving thing anyone did in these conversations was simply stay without demanding a performance.

If you recognised yourself in the clipboard, the landlord, the guard, the weather, the endless play, the hallway, the alarm, the scanner, the witness, the empty space, the thermostat, or the quiet radio, you are not the only person sitting with a third chair.

The experiment was never to evict them on air. It was to introduce them. Once something has been introduced, it is harder to pretend the room is empty. It is also harder to let the guest decide who lives there.

The illnesses may occupy rooms. They may rearrange the furniture. They may turn the lights off. They may sometimes convince the person there is no door. But they are not the whole house. A diagnosis can describe a person's experience without becoming their identity.

The other person may always be in the room. But they don't necessarily get to decide who lives there.

I'm Adam James. Thank you for sitting in these rooms with us. If you need support in Australia: Lifeline, thirteen eleven fourteen. Beyond Blue, thirteen hundred twenty-two forty-six thirty-six.

---

**End of expanded shooting scripts.**
Perform at conversational pace with interruptions left in. Target 10–15 minutes per episode.
